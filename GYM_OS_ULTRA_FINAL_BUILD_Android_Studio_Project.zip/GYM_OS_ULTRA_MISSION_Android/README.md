# GYM OS ULTRA

Android Studio project for GYM OS ULTRA Mission edition.

- App display name: GYM OS ULTRA
- Application ID: com.gymos.ultra
- Debug APK filename: GYM-OS-ULTRA-debug.apk
- Launcher icon: custom GYM OS ULTRA icon

# GYM OS ULTRA v2 — Mission Edition
Open this folder in Android Studio and build an APK using:
Build → Build APK(s)

Features added:
- Daily and weekly missions
- XP + levels
- Streaks
- Mission completion
- Achievements counter
- Recovery-day mission
- LocalStorage persistence
- Existing workout tracker remains included

The HTML uses Chart.js from a CDN, so charts need internet unless Chart.js is bundled locally.

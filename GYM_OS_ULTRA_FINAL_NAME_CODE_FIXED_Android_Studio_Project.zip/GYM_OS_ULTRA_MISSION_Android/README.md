# GYM OS ULTRA — Android Studio Project

App display name: **GYM OS ULTRA**

APK build type: **Debug**

The generated APK filename is **GYM-OS-ULTRA-debug.apk**.

The Android launcher icon is configured through `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round`.
